#### 全局主题色变更
1. css调整: 
> style/common.wxss
```css
page {
    --main-color: #1684fc;
    --main-color-shadow: #92bce9;
}

```
2. js调整
> /app.js
```JavaScript
globalData: {
    ...
    mainColor: '#1684fc'
  },
```